-- ============================================================
-- База данных: box_management
-- Тема курсовой работы: Коробка
-- ============================================================

-- Создание базы данных
-- CREATE DATABASE box_management;
-- \c box_management;

-- ============================================================
-- ТАБЛИЦЫ
-- ============================================================

-- Таблица категорий коробок
CREATE TABLE IF NOT EXISTS categories (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Таблица пользователей
CREATE TABLE IF NOT EXISTS users (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    age INTEGER,
    role VARCHAR(20) NOT NULL DEFAULT 'user' CHECK (role IN ('admin', 'manager', 'user')),
    password_hash VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Таблица коробок
CREATE TABLE IF NOT EXISTS boxes (
    id SERIAL PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    description TEXT,
    length_cm NUMERIC(10,2) NOT NULL CHECK (length_cm > 0),
    width_cm NUMERIC(10,2) NOT NULL CHECK (width_cm > 0),
    height_cm NUMERIC(10,2) NOT NULL CHECK (height_cm > 0),
    weight_kg NUMERIC(10,3),
    material VARCHAR(100),
    color VARCHAR(50),
    price NUMERIC(10,2) CHECK (price >= 0),
    stock_quantity INTEGER DEFAULT 0 CHECK (stock_quantity >= 0),
    category_id INTEGER REFERENCES categories(id) ON DELETE SET NULL,
    created_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Таблица заказов
CREATE TABLE IF NOT EXISTS orders (
    id SERIAL PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    box_id INTEGER NOT NULL REFERENCES boxes(id) ON DELETE CASCADE,
    quantity INTEGER NOT NULL CHECK (quantity > 0),
    total_price NUMERIC(10,2) NOT NULL CHECK (total_price >= 0),
    status VARCHAR(30) NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','confirmed','shipped','delivered','cancelled')),
    notes TEXT,
    ordered_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================
-- ПРЕДСТАВЛЕНИЯ (VIEWS)
-- ============================================================

-- 1. Представление: полная информация о коробках с категорией
CREATE OR REPLACE VIEW view_boxes_full AS
SELECT
    b.id,
    b.name,
    b.description,
    b.length_cm,
    b.width_cm,
    b.height_cm,
    ROUND((b.length_cm * b.width_cm * b.height_cm) / 1000.0, 2) AS volume_liters,
    b.weight_kg,
    b.material,
    b.color,
    b.price,
    b.stock_quantity,
    c.name AS category_name,
    u.name AS created_by_name,
    b.created_at
FROM boxes b
LEFT JOIN categories c ON b.category_id = c.id
LEFT JOIN users u ON b.created_by = u.id;

-- 2. Представление: статистика заказов по пользователям
CREATE OR REPLACE VIEW view_user_orders_stats AS
SELECT
    u.id AS user_id,
    u.name AS user_name,
    u.email,
    u.role,
    COUNT(o.id) AS total_orders,
    COALESCE(SUM(o.total_price), 0) AS total_spent,
    COALESCE(AVG(o.total_price), 0) AS avg_order_value,
    MAX(o.ordered_at) AS last_order_date
FROM users u
LEFT JOIN orders o ON u.id = o.user_id
GROUP BY u.id, u.name, u.email, u.role;

-- 3. Представление: активные заказы (не отменённые и не доставленные)
CREATE OR REPLACE VIEW view_active_orders AS
SELECT
    o.id AS order_id,
    u.name AS user_name,
    u.email AS user_email,
    b.name AS box_name,
    o.quantity,
    o.total_price,
    o.status,
    o.ordered_at
FROM orders o
JOIN users u ON o.user_id = u.id
JOIN boxes b ON o.box_id = b.id
WHERE o.status NOT IN ('delivered', 'cancelled')
ORDER BY o.ordered_at DESC;

-- ============================================================
-- ФУНКЦИИ
-- ============================================================

-- 1. Функция: вычисление объёма коробки в литрах
CREATE OR REPLACE FUNCTION get_box_volume(box_id INTEGER)
RETURNS NUMERIC AS $$
DECLARE
    vol NUMERIC;
BEGIN
    SELECT ROUND((length_cm * width_cm * height_cm) / 1000.0, 2)
    INTO vol
    FROM boxes WHERE id = box_id;
    RETURN vol;
END;
$$ LANGUAGE plpgsql;

-- 2. Функция: получение итоговой суммы заказов пользователя
CREATE OR REPLACE FUNCTION get_user_total_spent(p_user_id INTEGER)
RETURNS NUMERIC AS $$
DECLARE
    total NUMERIC;
BEGIN
    SELECT COALESCE(SUM(total_price), 0)
    INTO total
    FROM orders
    WHERE user_id = p_user_id AND status != 'cancelled';
    RETURN total;
END;
$$ LANGUAGE plpgsql;

-- 3. Функция: проверка наличия достаточного количества коробок на складе
CREATE OR REPLACE FUNCTION check_stock_availability(p_box_id INTEGER, p_quantity INTEGER)
RETURNS BOOLEAN AS $$
DECLARE
    available INTEGER;
BEGIN
    SELECT stock_quantity INTO available FROM boxes WHERE id = p_box_id;
    IF available IS NULL THEN
        RETURN FALSE;
    END IF;
    RETURN available >= p_quantity;
END;
$$ LANGUAGE plpgsql;

-- ============================================================
-- ХРАНИМЫЕ ПРОЦЕДУРЫ
-- ============================================================

-- 1. Процедура: создание нового заказа с проверкой склада
CREATE OR REPLACE PROCEDURE create_order(
    p_user_id INTEGER,
    p_box_id INTEGER,
    p_quantity INTEGER,
    p_notes TEXT DEFAULT NULL
)
LANGUAGE plpgsql AS $$
DECLARE
    v_price NUMERIC;
    v_total NUMERIC;
BEGIN
    -- Проверяем наличие
    IF NOT check_stock_availability(p_box_id, p_quantity) THEN
        RAISE EXCEPTION 'Недостаточно товара на складе для box_id=%', p_box_id;
    END IF;

    -- Получаем цену
    SELECT price INTO v_price FROM boxes WHERE id = p_box_id;
    v_total := v_price * p_quantity;

    -- Создаём заказ
    INSERT INTO orders (user_id, box_id, quantity, total_price, notes)
    VALUES (p_user_id, p_box_id, p_quantity, v_total, p_notes);

    -- Обновляем склад
    UPDATE boxes SET stock_quantity = stock_quantity - p_quantity,
                     updated_at = CURRENT_TIMESTAMP
    WHERE id = p_box_id;

    RAISE NOTICE 'Заказ создан для пользователя % на коробку %', p_user_id, p_box_id;
END;
$$;

-- 2. Процедура: отмена заказа с возвратом на склад
CREATE OR REPLACE PROCEDURE cancel_order(p_order_id INTEGER)
LANGUAGE plpgsql AS $$
DECLARE
    v_box_id INTEGER;
    v_qty INTEGER;
    v_status VARCHAR;
BEGIN
    SELECT box_id, quantity, status INTO v_box_id, v_qty, v_status
    FROM orders WHERE id = p_order_id;

    IF v_status = 'cancelled' THEN
        RAISE EXCEPTION 'Заказ % уже отменён', p_order_id;
    END IF;

    IF v_status = 'delivered' THEN
        RAISE EXCEPTION 'Нельзя отменить доставленный заказ %', p_order_id;
    END IF;

    UPDATE orders SET status = 'cancelled', updated_at = CURRENT_TIMESTAMP
    WHERE id = p_order_id;

    UPDATE boxes SET stock_quantity = stock_quantity + v_qty,
                     updated_at = CURRENT_TIMESTAMP
    WHERE id = v_box_id;

    RAISE NOTICE 'Заказ % отменён, склад обновлён', p_order_id;
END;
$$;

-- 3. Процедура: обновление статуса заказа
CREATE OR REPLACE PROCEDURE update_order_status(p_order_id INTEGER, p_new_status VARCHAR)
LANGUAGE plpgsql AS $$
BEGIN
    IF p_new_status NOT IN ('pending','confirmed','shipped','delivered','cancelled') THEN
        RAISE EXCEPTION 'Неверный статус: %', p_new_status;
    END IF;

    UPDATE orders SET status = p_new_status, updated_at = CURRENT_TIMESTAMP
    WHERE id = p_order_id;

    RAISE NOTICE 'Статус заказа % обновлён до %', p_order_id, p_new_status;
END;
$$;

-- ============================================================
-- ТРИГГЕРЫ
-- ============================================================

-- 1. Триггер: автоматическое обновление updated_at для boxes
CREATE OR REPLACE FUNCTION trigger_update_boxes_timestamp()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_boxes_updated_at
BEFORE UPDATE ON boxes
FOR EACH ROW EXECUTE FUNCTION trigger_update_boxes_timestamp();

-- 2. Триггер: автоматическое обновление updated_at для orders
CREATE OR REPLACE FUNCTION trigger_update_orders_timestamp()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_orders_updated_at
BEFORE UPDATE ON orders
FOR EACH ROW EXECUTE FUNCTION trigger_update_orders_timestamp();

-- 3. Триггер: запрет удаления категории, если к ней привязаны коробки
CREATE OR REPLACE FUNCTION trigger_prevent_category_delete()
RETURNS TRIGGER AS $$
DECLARE
    cnt INTEGER;
BEGIN
    SELECT COUNT(*) INTO cnt FROM boxes WHERE category_id = OLD.id;
    IF cnt > 0 THEN
        RAISE EXCEPTION 'Нельзя удалить категорию "%": к ней привязаны % коробок', OLD.name, cnt;
    END IF;
    RETURN OLD;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_prevent_category_delete
BEFORE DELETE ON categories
FOR EACH ROW EXECUTE FUNCTION trigger_prevent_category_delete();

-- ============================================================
-- ТЕСТОВЫЕ ДАННЫЕ
-- ============================================================

-- Категории
INSERT INTO categories (name, description) VALUES
    ('Картонные', 'Коробки из гофрированного и обычного картона'),
    ('Деревянные', 'Коробки и ящики из натуральной древесины'),
    ('Пластиковые', 'Контейнеры и боксы из различных видов пластика'),
    ('Подарочные', 'Декоративные коробки для упаковки подарков'),
    ('Металлические', 'Металлические контейнеры и коробки'),
    ('Архивные', 'Коробки для долгосрочного хранения документов');

-- Пользователи (пароли захешированы: все "password123" в bcrypt)
INSERT INTO users (name, email, age, role, password_hash) VALUES
    ('Иванов Иван Иванович', 'ivanov@example.com', 35, 'admin', '$2b$10$examplehashforadmin1234567890abcdef'),
    ('Петрова Мария Сергеевна', 'petrova@example.com', 28, 'manager', '$2b$10$examplehashformanager123456789abcdef'),
    ('Сидоров Алексей Петрович', 'sidorov@example.com', 42, 'user', '$2b$10$examplehashforuser1234567890abcdef'),
    ('Козлова Анна Дмитриевна', 'kozlova@example.com', 31, 'user', '$2b$10$examplehashforuser2234567890abcdef'),
    ('Новиков Дмитрий Андреевич', 'novikov@example.com', 25, 'user', '$2b$10$examplehashforuser3234567890abcdef'),
    ('Морозова Елена Викторовна', 'morozova@example.com', 38, 'manager', '$2b$10$examplehashformanager223456789abcdef'),
    ('Волков Сергей Николаевич', 'volkov@example.com', 45, 'user', '$2b$10$examplehashforuser4234567890abcdef'),
    ('Лебедева Ольга Александровна', 'lebedeva@example.com', 29, 'user', '$2b$10$examplehashforuser5234567890abcdef');

-- Коробки
INSERT INTO boxes (name, description, length_cm, width_cm, height_cm, weight_kg, material, color, price, stock_quantity, category_id, created_by) VALUES
    ('Малая картонная коробка', 'Стандартная коробка для небольших товаров', 20, 15, 10, 0.150, 'Гофрокартон', 'Коричневый', 25.00, 500, 1, 1),
    ('Средняя картонная коробка', 'Универсальная коробка для переезда', 40, 30, 25, 0.350, 'Гофрокартон', 'Коричневый', 55.00, 300, 1, 1),
    ('Большая картонная коробка', 'Крупногабаритная коробка для переезда', 60, 50, 40, 0.600, 'Гофрокартон', 'Коричневый', 90.00, 150, 1, 1),
    ('Деревянный ящик малый', 'Сосновый ящик ручной работы', 25, 20, 15, 1.200, 'Сосна', 'Натуральный', 350.00, 50, 2, 2),
    ('Деревянный ящик средний', 'Ящик для хранения инструментов', 45, 35, 30, 2.500, 'Дуб', 'Натуральный', 650.00, 30, 2, 2),
    ('Пластиковый контейнер 5л', 'Прозрачный контейнер с крышкой', 22, 16, 14, 0.300, 'Полипропилен', 'Прозрачный', 120.00, 200, 3, 1),
    ('Пластиковый контейнер 10л', 'Контейнер для хранения сыпучих', 30, 22, 20, 0.450, 'Полипропилен', 'Белый', 185.00, 180, 3, 1),
    ('Подарочная коробка малая', 'Коробка с бантом для подарков', 15, 15, 10, 0.100, 'Мелованный картон', 'Красный', 80.00, 100, 4, 2),
    ('Подарочная коробка сердце', 'Коробка в форме сердца', 20, 20, 8, 0.120, 'Мелованный картон', 'Розовый', 120.00, 75, 4, 2),
    ('Подарочный набор коробок', 'Набор из 3 вложенных коробок', 30, 30, 20, 0.400, 'Мелованный картон', 'Золотой', 250.00, 60, 4, 2),
    ('Металлическая банка-коробка', 'Жестяная коробка с крышкой', 18, 12, 8, 0.280, 'Жесть', 'Серебристый', 180.00, 120, 5, 1),
    ('Архивная коробка А4', 'Для хранения документов формата А4', 32, 26, 10, 0.250, 'Плотный картон', 'Серый', 70.00, 250, 6, 2),
    ('Архивная коробка А3', 'Для хранения документов формата А3', 45, 35, 12, 0.380, 'Плотный картон', 'Серый', 110.00, 120, 6, 2),
    ('Ящик металлический складской', 'Промышленный металлический ящик', 50, 40, 35, 4.500, 'Сталь', 'Серый', 1200.00, 20, 5, 1),
    ('Деревянная шкатулка', 'Декоративная шкатулка из красного дерева', 20, 15, 10, 0.800, 'Красное дерево', 'Тёмно-коричневый', 890.00, 25, 2, 2);

-- Заказы
INSERT INTO orders (user_id, box_id, quantity, total_price, status, notes) VALUES
    (3, 1, 10, 250.00, 'delivered', 'Доставка на склад'),
    (3, 2, 5, 275.00, 'delivered', NULL),
    (4, 8, 2, 160.00, 'delivered', 'Подарок на день рождения'),
    (4, 9, 1, 120.00, 'shipped', NULL),
    (5, 6, 3, 360.00, 'confirmed', 'Для домашнего использования'),
    (5, 12, 10, 700.00, 'pending', 'Срочно нужны'),
    (7, 4, 2, 700.00, 'delivered', NULL),
    (7, 5, 1, 650.00, 'cancelled', 'Клиент передумал'),
    (8, 10, 3, 750.00, 'shipped', NULL),
    (8, 11, 5, 900.00, 'confirmed', 'Под заказ'),
    (3, 3, 4, 360.00, 'pending', NULL),
    (4, 13, 2, 220.00, 'delivered', 'Для архива офиса'),
    (5, 14, 1, 1200.00, 'confirmed', 'Промышленное использование'),
    (7, 15, 1, 890.00, 'pending', 'Подарок'),
    (8, 7, 4, 740.00, 'shipped', NULL);
