import React from 'react';
import { BrowserRouter, Routes, Route, Navigate, Link, useNavigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './services/AuthContext';
import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/RegisterPage';
import BoxesPage from './pages/BoxesPage';
import BoxDetailPage from './pages/BoxDetailPage';
import OrdersPage from './pages/OrdersPage';
import UsersPage from './pages/UsersPage';
import CategoriesPage from './pages/CategoriesPage';
import './App.css';

function Navbar() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => { logout(); navigate('/login'); };

  return (
    <nav className="navbar">
      <div className="navbar-brand">
        <span className="box-icon">📦</span>
        <Link to="/">BoxManager</Link>
      </div>
      <div className="navbar-links">
        <Link to="/boxes">Коробки</Link>
        <Link to="/categories">Категории</Link>
        {user && <Link to="/orders">Заказы</Link>}
        {user && (user.role === 'admin' || user.role === 'manager') && (
          <Link to="/users">Пользователи</Link>
        )}
      </div>
      <div className="navbar-user">
        {user ? (
          <>
            <span className="user-info">
              {user.name} <span className={`role-badge role-${user.role}`}>{user.role}</span>
            </span>
            <button onClick={handleLogout} className="btn-logout">Выйти</button>
          </>
        ) : (
          <>
            <Link to="/login" className="btn-link">Войти</Link>
            <Link to="/register" className="btn-link btn-primary">Регистрация</Link>
          </>
        )}
      </div>
    </nav>
  );
}

function ProtectedRoute({ children }) {
  const { user, loading } = useAuth();
  if (loading) return <div className="loading">Загрузка...</div>;
  if (!user) return <Navigate to="/login" />;
  return children;
}

function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Navbar />
        <main className="main-content">
          <Routes>
            <Route path="/" element={<Navigate to="/boxes" />} />
            <Route path="/login" element={<LoginPage />} />
            <Route path="/register" element={<RegisterPage />} />
            <Route path="/boxes" element={<BoxesPage />} />
            <Route path="/boxes/:id" element={<BoxDetailPage />} />
            <Route path="/categories" element={<CategoriesPage />} />
            <Route path="/orders" element={<ProtectedRoute><OrdersPage /></ProtectedRoute>} />
            <Route path="/users" element={<ProtectedRoute><UsersPage /></ProtectedRoute>} />
          </Routes>
        </main>
      </BrowserRouter>
    </AuthProvider>
  );
}

export default App;
