import React, { useState, useEffect } from 'react';
import { usersApi } from '../services/api';
import { useAuth } from '../services/AuthContext';

const ROLE_LABELS = { admin: 'Администратор', manager: 'Менеджер', user: 'Пользователь' };

export default function UsersPage() {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editUser, setEditUser] = useState(null);
  const { user: me } = useAuth();

  const load = () => usersApi.getAll().then(r => { setUsers(r.data); setLoading(false); });
  useEffect(() => { load(); }, []);

  const handleDelete = async (id) => {
    if (id === me.id) { alert('Нельзя удалить себя'); return; }
    if (!window.confirm('Удалить пользователя?')) return;
    await usersApi.remove(id);
    load();
  };

  const handleSave = async (e) => {
    e.preventDefault();
    const fd = new FormData(e.target);
    const data = { name: fd.get('name'), email: fd.get('email'), role: fd.get('role') };
    if (fd.get('age')) data.age = parseInt(fd.get('age'));
    await usersApi.update(editUser.id, data);
    setEditUser(null);
    load();
  };

  return (
    <div>
      <div className="page-header"><h1 className="page-title">👥 Пользователи</h1></div>
      {loading ? <div className="loading">Загрузка...</div> : (
        <div className="table-container">
          <table>
            <thead><tr><th>#</th><th>Имя</th><th>Email</th><th>Возраст</th><th>Роль</th><th>Регистрация</th><th>Действия</th></tr></thead>
            <tbody>
              {users.map(u => (
                <tr key={u.id}>
                  <td>{u.id}</td>
                  <td><strong>{u.name}</strong>{u.id === me.id && <span style={{ color: '#3498db', fontSize: '0.75rem' }}> (вы)</span>}</td>
                  <td>{u.email}</td>
                  <td>{u.age || '—'}</td>
                  <td><span className={`role-badge role-${u.role}`}>{ROLE_LABELS[u.role]}</span></td>
                  <td>{new Date(u.createdAt).toLocaleDateString('ru-RU')}</td>
                  <td>
                    {me.role === 'admin' && (
                      <div style={{ display: 'flex', gap: '4px' }}>
                        <button className="btn btn-warning" style={{ fontSize: '0.75rem', padding: '4px 8px' }} onClick={() => setEditUser(u)}>✏️</button>
                        <button className="btn btn-danger" style={{ fontSize: '0.75rem', padding: '4px 8px' }} onClick={() => handleDelete(u.id)}>🗑️</button>
                      </div>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      {editUser && (
        <div className="modal-overlay" onClick={() => setEditUser(null)}>
          <div className="modal" onClick={e => e.stopPropagation()}>
            <div className="modal-title">Редактировать пользователя</div>
            <form onSubmit={handleSave}>
              <div className="form-group"><label className="form-label">Имя</label>
                <input className="form-input" name="name" defaultValue={editUser.name} required /></div>
              <div className="form-group"><label className="form-label">Email</label>
                <input className="form-input" name="email" type="email" defaultValue={editUser.email} required /></div>
              <div className="form-group"><label className="form-label">Возраст</label>
                <input className="form-input" name="age" type="number" defaultValue={editUser.age} /></div>
              <div className="form-group"><label className="form-label">Роль</label>
                <select className="form-select" name="role" defaultValue={editUser.role}>
                  <option value="user">Пользователь</option>
                  <option value="manager">Менеджер</option>
                  <option value="admin">Администратор</option>
                </select></div>
              <div className="card-actions">
                <button type="submit" className="btn btn-success">Сохранить</button>
                <button type="button" className="btn btn-secondary" onClick={() => setEditUser(null)}>Отмена</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
