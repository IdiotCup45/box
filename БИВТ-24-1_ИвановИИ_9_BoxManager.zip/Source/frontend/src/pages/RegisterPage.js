import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { usersApi } from '../services/api';
import { useAuth } from '../services/AuthContext';

export default function RegisterPage() {
  const [form, setForm] = useState({ name: '', email: '', age: '', password: '' });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    if (form.password.length < 6) { setError('Пароль должен быть не менее 6 символов'); return; }
    setLoading(true);
    try {
      await usersApi.create({ ...form, age: form.age ? parseInt(form.age) : undefined });
      await login(form.email, form.password);
      navigate('/boxes');
    } catch (err) {
      setError(err.response?.data?.message || 'Ошибка регистрации');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="auth-page">
      <div className="auth-card">
        <div className="auth-title">📦 Регистрация</div>
        {error && <div className="alert alert-error">{error}</div>}
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label className="form-label">Имя *</label>
            <input className="form-input" required placeholder="Иванов Иван Иванович"
              value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} />
          </div>
          <div className="form-group">
            <label className="form-label">Email *</label>
            <input className="form-input" type="email" required placeholder="example@mail.com"
              value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} />
          </div>
          <div className="form-group">
            <label className="form-label">Возраст</label>
            <input className="form-input" type="number" min="0" max="120" placeholder="Необязательно"
              value={form.age} onChange={e => setForm({ ...form, age: e.target.value })} />
          </div>
          <div className="form-group">
            <label className="form-label">Пароль *</label>
            <input className="form-input" type="password" required placeholder="Минимум 6 символов"
              value={form.password} onChange={e => setForm({ ...form, password: e.target.value })} />
          </div>
          <button className="auth-submit" type="submit" disabled={loading}>
            {loading ? 'Регистрация...' : 'Зарегистрироваться'}
          </button>
        </form>
        <p className="auth-link">Уже есть аккаунт? <Link to="/login">Войти</Link></p>
      </div>
    </div>
  );
}
