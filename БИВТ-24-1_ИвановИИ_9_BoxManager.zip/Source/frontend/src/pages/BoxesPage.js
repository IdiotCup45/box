import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { boxesApi, categoriesApi } from '../services/api';
import { useAuth } from '../services/AuthContext';

function BoxModal({ box, categories, onClose, onSave }) {
  const [form, setForm] = useState(box || { name: '', description: '', lengthCm: '', widthCm: '', heightCm: '', weightKg: '', material: '', color: '', price: '', stockQuantity: 0, categoryId: '' });
  const [error, setError] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    try {
      const data = {
        ...form,
        lengthCm: parseFloat(form.lengthCm),
        widthCm: parseFloat(form.widthCm),
        heightCm: parseFloat(form.heightCm),
        weightKg: form.weightKg ? parseFloat(form.weightKg) : undefined,
        price: form.price ? parseFloat(form.price) : undefined,
        stockQuantity: parseInt(form.stockQuantity) || 0,
        categoryId: form.categoryId ? parseInt(form.categoryId) : undefined,
      };
      await onSave(data);
      onClose();
    } catch (err) {
      setError(err.response?.data?.message || 'Ошибка сохранения');
    }
  };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal" onClick={e => e.stopPropagation()}>
        <div className="modal-title">{box?.id ? 'Редактировать коробку' : 'Добавить коробку'}</div>
        {error && <div className="alert alert-error">{error}</div>}
        <form onSubmit={handleSubmit}>
          <div className="form-group"><label className="form-label">Название *</label>
            <input className="form-input" required value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} /></div>
          <div className="form-group"><label className="form-label">Описание</label>
            <input className="form-input" value={form.description || ''} onChange={e => setForm({ ...form, description: e.target.value })} /></div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '0.5rem' }}>
            <div className="form-group"><label className="form-label">Длина (см) *</label>
              <input className="form-input" type="number" step="0.01" min="0.01" required value={form.lengthCm} onChange={e => setForm({ ...form, lengthCm: e.target.value })} /></div>
            <div className="form-group"><label className="form-label">Ширина (см) *</label>
              <input className="form-input" type="number" step="0.01" min="0.01" required value={form.widthCm} onChange={e => setForm({ ...form, widthCm: e.target.value })} /></div>
            <div className="form-group"><label className="form-label">Высота (см) *</label>
              <input className="form-input" type="number" step="0.01" min="0.01" required value={form.heightCm} onChange={e => setForm({ ...form, heightCm: e.target.value })} /></div>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.5rem' }}>
            <div className="form-group"><label className="form-label">Вес (кг)</label>
              <input className="form-input" type="number" step="0.001" value={form.weightKg || ''} onChange={e => setForm({ ...form, weightKg: e.target.value })} /></div>
            <div className="form-group"><label className="form-label">Цена (₽)</label>
              <input className="form-input" type="number" step="0.01" value={form.price || ''} onChange={e => setForm({ ...form, price: e.target.value })} /></div>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.5rem' }}>
            <div className="form-group"><label className="form-label">Материал</label>
              <input className="form-input" value={form.material || ''} onChange={e => setForm({ ...form, material: e.target.value })} /></div>
            <div className="form-group"><label className="form-label">Цвет</label>
              <input className="form-input" value={form.color || ''} onChange={e => setForm({ ...form, color: e.target.value })} /></div>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.5rem' }}>
            <div className="form-group"><label className="form-label">Кол-во на складе</label>
              <input className="form-input" type="number" min="0" value={form.stockQuantity} onChange={e => setForm({ ...form, stockQuantity: e.target.value })} /></div>
            <div className="form-group"><label className="form-label">Категория</label>
              <select className="form-select" value={form.categoryId || ''} onChange={e => setForm({ ...form, categoryId: e.target.value })}>
                <option value="">— Без категории —</option>
                {categories.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
              </select></div>
          </div>
          <div className="card-actions">
            <button type="submit" className="btn btn-success">Сохранить</button>
            <button type="button" className="btn btn-secondary" onClick={onClose}>Отмена</button>
          </div>
        </form>
      </div>
    </div>
  );
}

export default function BoxesPage() {
  const [boxes, setBoxes] = useState([]);
  const [categories, setCategories] = useState([]);
  const [filter, setFilter] = useState('');
  const [catFilter, setCatFilter] = useState('');
  const [loading, setLoading] = useState(true);
  const [modal, setModal] = useState(null);
  const { user } = useAuth();
  const navigate = useNavigate();
  const canManage = user && (user.role === 'admin' || user.role === 'manager');

  const load = async () => {
    try {
      const [bRes, cRes] = await Promise.all([boxesApi.getAll(catFilter || undefined), categoriesApi.getAll()]);
      setBoxes(bRes.data);
      setCategories(cRes.data);
    } finally { setLoading(false); }
  };

  useEffect(() => { load(); }, [catFilter]);

  const filtered = boxes.filter(b =>
    b.name.toLowerCase().includes(filter.toLowerCase()) ||
    (b.material && b.material.toLowerCase().includes(filter.toLowerCase()))
  );

  const handleDelete = async (id) => {
    if (!window.confirm('Удалить коробку?')) return;
    await boxesApi.remove(id);
    load();
  };

  const handleSave = async (data) => {
    if (modal.id) await boxesApi.update(modal.id, data);
    else await boxesApi.create(data);
    load();
  };

  const stockClass = (qty) => qty === 0 ? 'stock-empty' : qty < 20 ? 'stock-low' : 'stock-ok';

  return (
    <div>
      <div className="page-header">
        <h1 className="page-title">📦 Каталог коробок</h1>
        {canManage && <button className="btn btn-success" onClick={() => setModal({})}>+ Добавить</button>}
      </div>
      <div className="filters">
        <input className="filter-input" placeholder="🔍 Поиск по названию или материалу..."
          value={filter} onChange={e => setFilter(e.target.value)} style={{ flexGrow: 1 }} />
        <select className="filter-input" value={catFilter} onChange={e => setCatFilter(e.target.value)}>
          <option value="">Все категории</option>
          {categories.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
        </select>
      </div>
      {loading ? <div className="loading">Загрузка...</div> : (
        <div className="cards-grid">
          {filtered.map(box => (
            <div key={box.id} className="card">
              <div className="card-title">{box.name}</div>
              <div className="card-subtitle">{box.category?.name || 'Без категории'}</div>
              <div className="card-info">📐 {box.lengthCm}×{box.widthCm}×{box.heightCm} см</div>
              {box.material && <div className="card-info">🧱 {box.material} {box.color ? `· ${box.color}` : ''}</div>}
              <div className="card-price">{box.price ? `${Number(box.price).toLocaleString()} ₽` : 'Цена не указана'}</div>
              <div className="card-info">
                Склад: <span className={stockClass(box.stockQuantity)}>{box.stockQuantity} шт.</span>
              </div>
              <div className="card-actions">
                <button className="btn btn-outline" onClick={() => navigate(`/boxes/${box.id}`)}>Подробнее</button>
                {canManage && <>
                  <button className="btn btn-warning" onClick={() => setModal(box)}>✏️</button>
                  <button className="btn btn-danger" onClick={() => handleDelete(box.id)}>🗑️</button>
                </>}
              </div>
            </div>
          ))}
        </div>
      )}
      {filtered.length === 0 && !loading && <p style={{ textAlign: 'center', color: '#666', marginTop: '2rem' }}>Коробки не найдены</p>}
      {modal !== null && <BoxModal box={modal.id ? modal : null} categories={categories} onClose={() => setModal(null)} onSave={handleSave} />}
    </div>
  );
}
