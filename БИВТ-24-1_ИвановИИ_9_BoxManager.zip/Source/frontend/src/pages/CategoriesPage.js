import React, { useState, useEffect } from 'react';
import { categoriesApi } from '../services/api';
import { useAuth } from '../services/AuthContext';

export default function CategoriesPage() {
  const [cats, setCats] = useState([]);
  const [loading, setLoading] = useState(true);
  const [modal, setModal] = useState(null);
  const [form, setForm] = useState({ name: '', description: '' });
  const [error, setError] = useState('');
  const { user } = useAuth();
  const canManage = user && (user.role === 'admin' || user.role === 'manager');

  const load = () => categoriesApi.getAll().then(r => { setCats(r.data); setLoading(false); });
  useEffect(() => { load(); }, []);

  const openModal = (cat = null) => {
    setForm(cat ? { name: cat.name, description: cat.description || '' } : { name: '', description: '' });
    setModal(cat || {});
    setError('');
  };

  const handleSave = async (e) => {
    e.preventDefault();
    try {
      if (modal.id) await categoriesApi.update(modal.id, form);
      else await categoriesApi.create(form);
      setModal(null);
      load();
    } catch (err) { setError(err.response?.data?.message || 'Ошибка'); }
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Удалить категорию?')) return;
    try { await categoriesApi.remove(id); load(); }
    catch (err) { alert(err.response?.data?.message || 'Ошибка удаления'); }
  };

  return (
    <div>
      <div className="page-header">
        <h1 className="page-title">🗂️ Категории</h1>
        {canManage && <button className="btn btn-success" onClick={() => openModal()}>+ Добавить</button>}
      </div>
      {loading ? <div className="loading">Загрузка...</div> : (
        <div className="cards-grid">
          {cats.map(cat => (
            <div key={cat.id} className="card">
              <div className="card-title">🗂️ {cat.name}</div>
              <div className="card-info" style={{ color: '#555' }}>{cat.description || 'Без описания'}</div>
              <div className="card-info" style={{ marginTop: '0.5rem', color: '#7f8c8d', fontSize: '0.8rem' }}>
                Добавлено: {new Date(cat.createdAt).toLocaleDateString('ru-RU')}
              </div>
              {canManage && (
                <div className="card-actions">
                  <button className="btn btn-warning" onClick={() => openModal(cat)}>✏️ Редактировать</button>
                  {user.role === 'admin' && <button className="btn btn-danger" onClick={() => handleDelete(cat.id)}>🗑️</button>}
                </div>
              )}
            </div>
          ))}
        </div>
      )}
      {modal !== null && (
        <div className="modal-overlay" onClick={() => setModal(null)}>
          <div className="modal" onClick={e => e.stopPropagation()}>
            <div className="modal-title">{modal.id ? 'Редактировать категорию' : 'Новая категория'}</div>
            {error && <div className="alert alert-error">{error}</div>}
            <form onSubmit={handleSave}>
              <div className="form-group"><label className="form-label">Название *</label>
                <input className="form-input" required value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} /></div>
              <div className="form-group"><label className="form-label">Описание</label>
                <textarea className="form-input" rows={3} value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} /></div>
              <div className="card-actions">
                <button type="submit" className="btn btn-success">Сохранить</button>
                <button type="button" className="btn btn-secondary" onClick={() => setModal(null)}>Отмена</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
