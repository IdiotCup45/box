import React, { useState, useEffect } from 'react';
import { ordersApi } from '../services/api';
import { useAuth } from '../services/AuthContext';

const STATUS_LABELS = {
  pending: 'Ожидает', confirmed: 'Подтверждён', shipped: 'Отправлен',
  delivered: 'Доставлен', cancelled: 'Отменён',
};

const NEXT_STATUSES = {
  pending: ['confirmed', 'cancelled'],
  confirmed: ['shipped', 'cancelled'],
  shipped: ['delivered', 'cancelled'],
  delivered: [], cancelled: [],
};

export default function OrdersPage() {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const { user } = useAuth();
  const isAdmin = user?.role === 'admin' || user?.role === 'manager';

  const load = async () => {
    const res = await (isAdmin ? ordersApi.getAll() : ordersApi.getMy());
    setOrders(res.data);
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const handleStatus = async (id, status) => {
    if (!window.confirm(`Изменить статус на "${STATUS_LABELS[status]}"?`)) return;
    await ordersApi.updateStatus(id, status);
    load();
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Удалить заказ?')) return;
    await ordersApi.remove(id);
    load();
  };

  return (
    <div>
      <div className="page-header">
        <h1 className="page-title">📋 {isAdmin ? 'Все заказы' : 'Мои заказы'}</h1>
      </div>
      {loading ? <div className="loading">Загрузка...</div> : (
        <div className="table-container">
          <table>
            <thead>
              <tr>
                <th>#</th>
                {isAdmin && <th>Пользователь</th>}
                <th>Коробка</th>
                <th>Кол-во</th>
                <th>Сумма</th>
                <th>Статус</th>
                <th>Дата</th>
                <th>Действия</th>
              </tr>
            </thead>
            <tbody>
              {orders.map(o => (
                <tr key={o.id}>
                  <td>{o.id}</td>
                  {isAdmin && <td>{o.user?.name || '—'}</td>}
                  <td>{o.box?.name}</td>
                  <td>{o.quantity} шт.</td>
                  <td><strong>{Number(o.totalPrice).toLocaleString()} ₽</strong></td>
                  <td>
                    <span className={`status-badge status-${o.status}`}>{STATUS_LABELS[o.status]}</span>
                  </td>
                  <td>{new Date(o.orderedAt).toLocaleDateString('ru-RU')}</td>
                  <td>
                    <div style={{ display: 'flex', gap: '4px', flexWrap: 'wrap' }}>
                      {(isAdmin ? NEXT_STATUSES[o.status] : (o.status === 'pending' ? ['cancelled'] : []))
                        .map(s => (
                          <button key={s} className={`btn ${s === 'cancelled' ? 'btn-danger' : 'btn-primary-solid'}`}
                            style={{ fontSize: '0.75rem', padding: '4px 8px' }}
                            onClick={() => handleStatus(o.id, s)}>
                            {STATUS_LABELS[s]}
                          </button>
                        ))}
                      {user?.role === 'admin' && (
                        <button className="btn btn-secondary" style={{ fontSize: '0.75rem', padding: '4px 8px' }}
                          onClick={() => handleDelete(o.id)}>🗑️</button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {orders.length === 0 && <p style={{ textAlign: 'center', padding: '2rem', color: '#666' }}>Заказов нет</p>}
        </div>
      )}
    </div>
  );
}
