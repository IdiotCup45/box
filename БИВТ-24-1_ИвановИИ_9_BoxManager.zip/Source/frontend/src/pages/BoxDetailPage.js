import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { boxesApi, ordersApi } from '../services/api';
import { useAuth } from '../services/AuthContext';

export default function BoxDetailPage() {
  const { id } = useParams();
  const [box, setBox] = useState(null);
  const [qty, setQty] = useState(1);
  const [loading, setLoading] = useState(true);
  const [orderLoading, setOrderLoading] = useState(false);
  const [msg, setMsg] = useState(null);
  const { user } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    boxesApi.getById(id)
      .then(res => setBox(res.data))
      .finally(() => setLoading(false));
  }, [id]);

  const handleOrder = async () => {
    if (!user) { navigate('/login'); return; }
    setOrderLoading(true);
    try {
      await ordersApi.create({ boxId: parseInt(id), quantity: qty });
      setMsg({ type: 'success', text: `Заказ на ${qty} шт. успешно оформлен!` });
      const res = await boxesApi.getById(id);
      setBox(res.data);
    } catch (err) {
      setMsg({ type: 'error', text: err.response?.data?.message || 'Ошибка оформления заказа' });
    } finally { setOrderLoading(false); }
  };

  if (loading) return <div className="loading">Загрузка...</div>;
  if (!box) return <div className="loading">Коробка не найдена</div>;

  const volume = (box.lengthCm * box.widthCm * box.heightCm / 1000).toFixed(2);

  return (
    <div>
      <button className="btn btn-secondary" style={{ marginBottom: '1rem' }} onClick={() => navigate(-1)}>
        ← Назад
      </button>
      <div className="box-detail">
        <h1 style={{ fontSize: '1.8rem', marginBottom: '0.5rem' }}>{box.name}</h1>
        <span style={{ color: '#7f8c8d', fontSize: '0.9rem' }}>{box.category?.name || 'Без категории'}</span>
        {box.description && <p style={{ marginTop: '1rem', color: '#555' }}>{box.description}</p>}

        <div className="detail-grid" style={{ marginTop: '1.5rem' }}>
          <div className="detail-item"><label>Размеры (Д×Ш×В)</label><span>{box.lengthCm}×{box.widthCm}×{box.heightCm} см</span></div>
          <div className="detail-item"><label>Объём</label><span>{volume} л</span></div>
          {box.weightKg && <div className="detail-item"><label>Вес</label><span>{box.weightKg} кг</span></div>}
          {box.material && <div className="detail-item"><label>Материал</label><span>{box.material}</span></div>}
          {box.color && <div className="detail-item"><label>Цвет</label><span>{box.color}</span></div>}
          <div className="detail-item"><label>На складе</label>
            <span className={box.stockQuantity === 0 ? 'stock-empty' : box.stockQuantity < 20 ? 'stock-low' : 'stock-ok'}>
              {box.stockQuantity} шт.
            </span>
          </div>
        </div>

        <div style={{ fontSize: '2rem', fontWeight: 'bold', color: '#27ae60', margin: '1.5rem 0 1rem' }}>
          {box.price ? `${Number(box.price).toLocaleString()} ₽` : 'Цена не указана'}
        </div>

        {msg && <div className={`alert ${msg.type === 'success' ? 'alert-success' : 'alert-error'}`}>{msg.text}</div>}

        {box.price && box.stockQuantity > 0 && (
          <div style={{ display: 'flex', gap: '1rem', alignItems: 'center', flexWrap: 'wrap' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              <label style={{ fontSize: '0.9rem', color: '#555' }}>Количество:</label>
              <input type="number" min="1" max={box.stockQuantity} value={qty}
                onChange={e => setQty(Math.min(parseInt(e.target.value) || 1, box.stockQuantity))}
                style={{ width: 80, padding: '8px', border: '1.5px solid #ddd', borderRadius: '8px', fontSize: '1rem' }} />
            </div>
            <button className="btn btn-success" onClick={handleOrder} disabled={orderLoading}>
              {orderLoading ? 'Оформляем...' : `🛒 Заказать на ${(Number(box.price) * qty).toLocaleString()} ₽`}
            </button>
          </div>
        )}
        {box.stockQuantity === 0 && <p style={{ color: '#e74c3c', fontWeight: 'bold' }}>Нет в наличии</p>}
      </div>
    </div>
  );
}
