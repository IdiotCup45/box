import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import {
  Entity, PrimaryGeneratedColumn, Column,
  CreateDateColumn, UpdateDateColumn,
  ManyToOne, JoinColumn,
} from 'typeorm';
import { User } from '../users/user.entity';
import { Box } from '../boxes/box.entity';
import {
  Injectable, NotFoundException, BadRequestException,
  Controller, Get, Post, Patch, Delete, Param, Body,
  ParseIntPipe, UseGuards, Request, ForbiddenException,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { IsInt, IsOptional, IsString, Min, IsIn } from 'class-validator';
import { Type } from 'class-transformer';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { RolesGuard } from '../auth/roles.guard';
import { Roles } from '../auth/roles.decorator';

@Entity('orders')
export class Order {
  @PrimaryGeneratedColumn()
  id: number;

  @ManyToOne(() => User, (u) => u.orders)
  @JoinColumn({ name: 'user_id' })
  user: User;

  @ManyToOne(() => Box, (b) => b.orders, { eager: true })
  @JoinColumn({ name: 'box_id' })
  box: Box;

  @Column()
  quantity: number;

  @Column({ name: 'total_price', type: 'numeric', precision: 10, scale: 2 })
  totalPrice: number;

  @Column({ length: 30, default: 'pending' })
  status: string;

  @Column({ nullable: true })
  notes: string;

  @CreateDateColumn({ name: 'ordered_at' })
  orderedAt: Date;

  @UpdateDateColumn({ name: 'updated_at' })
  updatedAt: Date;
}

class CreateOrderDto {
  @IsInt() @Min(1) @Type(() => Number) boxId: number;
  @IsInt() @Min(1) @Type(() => Number) quantity: number;
  @IsOptional() @IsString() notes?: string;
}

class UpdateOrderStatusDto {
  @IsIn(['pending', 'confirmed', 'shipped', 'delivered', 'cancelled'])
  status: string;
}

@Injectable()
export class OrdersService {
  constructor(
    @InjectRepository(Order) private repo: Repository<Order>,
    @InjectRepository(Box) private boxRepo: Repository<Box>,
  ) {}

  findAll() {
    return this.repo.find({ relations: ['user', 'box'] });
  }

  findByUser(userId: number) {
    return this.repo.find({ where: { user: { id: userId } }, relations: ['box'] });
  }

  async findOne(id: number) {
    const o = await this.repo.findOne({ where: { id }, relations: ['user', 'box'] });
    if (!o) throw new NotFoundException(`Заказ ${id} не найден`);
    return o;
  }

  async create(dto: CreateOrderDto, userId: number) {
    const box = await this.boxRepo.findOne({ where: { id: dto.boxId } });
    if (!box) throw new NotFoundException(`Коробка ${dto.boxId} не найдена`);
    if (box.stockQuantity < dto.quantity) {
      throw new BadRequestException(`Недостаточно товара на складе. Доступно: ${box.stockQuantity}`);
    }
    const totalPrice = Number(box.price) * dto.quantity;
    const order = this.repo.create({
      user: { id: userId } as any,
      box,
      quantity: dto.quantity,
      totalPrice,
      notes: dto.notes,
    });
    box.stockQuantity -= dto.quantity;
    await this.boxRepo.save(box);
    return this.repo.save(order);
  }

  async updateStatus(id: number, dto: UpdateOrderStatusDto, user: any) {
    const order = await this.findOne(id);
    if (user.role === 'user' && order.user.id !== user.id) {
      throw new ForbiddenException('Нет доступа к этому заказу');
    }
    if (order.status === 'cancelled') throw new BadRequestException('Заказ уже отменён');
    if (order.status === 'delivered') throw new BadRequestException('Нельзя изменить доставленный заказ');
    // Возврат на склад при отмене
    if (dto.status === 'cancelled' && order.status !== 'cancelled') {
      const box = await this.boxRepo.findOne({ where: { id: order.box.id } });
      box.stockQuantity += order.quantity;
      await this.boxRepo.save(box);
    }
    order.status = dto.status;
    return this.repo.save(order);
  }

  async remove(id: number) {
    const order = await this.findOne(id);
    await this.repo.remove(order);
  }
}

@Controller('orders')
@UseGuards(JwtAuthGuard)
export class OrdersController {
  constructor(private svc: OrdersService) {}

  @Get()
  @UseGuards(RolesGuard)
  @Roles('admin', 'manager')
  findAll() { return this.svc.findAll(); }

  @Get('my')
  findMy(@Request() req) { return this.svc.findByUser(req.user.id); }

  @Get(':id')
  findOne(@Param('id', ParseIntPipe) id: number) { return this.svc.findOne(id); }

  @Post()
  create(@Body() dto: CreateOrderDto, @Request() req) {
    return this.svc.create(dto, req.user.id);
  }

  @Patch(':id/status')
  updateStatus(
    @Param('id', ParseIntPipe) id: number,
    @Body() dto: UpdateOrderStatusDto,
    @Request() req,
  ) { return this.svc.updateStatus(id, dto, req.user); }

  @Delete(':id')
  @UseGuards(RolesGuard)
  @Roles('admin')
  remove(@Param('id', ParseIntPipe) id: number) { return this.svc.remove(id); }
}

@Module({
  imports: [TypeOrmModule.forFeature([Order, Box])],
  providers: [OrdersService],
  controllers: [OrdersController],
})
export class OrdersModule {}
