import {
  Entity, PrimaryGeneratedColumn, Column,
  CreateDateColumn, UpdateDateColumn,
  ManyToOne, JoinColumn, OneToMany,
} from 'typeorm';
import { Category } from '../categories/category.entity';
import { User } from '../users/user.entity';
import { Order } from '../orders/order.entity';

@Entity('boxes')
export class Box {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ length: 150 })
  name: string;

  @Column({ nullable: true })
  description: string;

  @Column({ name: 'length_cm', type: 'numeric', precision: 10, scale: 2 })
  lengthCm: number;

  @Column({ name: 'width_cm', type: 'numeric', precision: 10, scale: 2 })
  widthCm: number;

  @Column({ name: 'height_cm', type: 'numeric', precision: 10, scale: 2 })
  heightCm: number;

  @Column({ name: 'weight_kg', type: 'numeric', precision: 10, scale: 3, nullable: true })
  weightKg: number;

  @Column({ length: 100, nullable: true })
  material: string;

  @Column({ length: 50, nullable: true })
  color: string;

  @Column({ type: 'numeric', precision: 10, scale: 2, nullable: true })
  price: number;

  @Column({ name: 'stock_quantity', default: 0 })
  stockQuantity: number;

  @ManyToOne(() => Category, (cat) => cat.boxes, { nullable: true, eager: true })
  @JoinColumn({ name: 'category_id' })
  category: Category;

  @ManyToOne(() => User, (u) => u.boxes, { nullable: true })
  @JoinColumn({ name: 'created_by' })
  createdBy: User;

  @CreateDateColumn({ name: 'created_at' })
  createdAt: Date;

  @UpdateDateColumn({ name: 'updated_at' })
  updatedAt: Date;

  @OneToMany(() => Order, (o) => o.box)
  orders: Order[];
}
