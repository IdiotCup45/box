import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Box } from './box.entity';
import {
  Injectable, NotFoundException, Controller,
  Get, Post, Put, Delete, Param, Body, ParseIntPipe,
  UseGuards, Request, Query,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import {
  IsString, IsNotEmpty, IsOptional, IsNumber, Min, IsInt,
} from 'class-validator';
import { Type } from 'class-transformer';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { RolesGuard } from '../auth/roles.guard';
import { Roles } from '../auth/roles.decorator';

export class CreateBoxDto {
  @IsString() @IsNotEmpty() name: string;
  @IsOptional() @IsString() description?: string;
  @IsNumber() @Min(0.01) @Type(() => Number) lengthCm: number;
  @IsNumber() @Min(0.01) @Type(() => Number) widthCm: number;
  @IsNumber() @Min(0.01) @Type(() => Number) heightCm: number;
  @IsOptional() @IsNumber() @Type(() => Number) weightKg?: number;
  @IsOptional() @IsString() material?: string;
  @IsOptional() @IsString() color?: string;
  @IsOptional() @IsNumber() @Min(0) @Type(() => Number) price?: number;
  @IsOptional() @IsInt() @Min(0) @Type(() => Number) stockQuantity?: number;
  @IsOptional() @IsInt() @Type(() => Number) categoryId?: number;
}

@Injectable()
export class BoxesService {
  constructor(@InjectRepository(Box) private repo: Repository<Box>) {}

  findAll(categoryId?: number) {
    if (categoryId) {
      return this.repo.find({ where: { category: { id: categoryId } } });
    }
    return this.repo.find();
  }

  async findOne(id: number) {
    const box = await this.repo.findOne({ where: { id } });
    if (!box) throw new NotFoundException(`Коробка ${id} не найдена`);
    return box;
  }

  async create(dto: CreateBoxDto, userId: number) {
    const box = this.repo.create({
      name: dto.name,
      description: dto.description,
      lengthCm: dto.lengthCm,
      widthCm: dto.widthCm,
      heightCm: dto.heightCm,
      weightKg: dto.weightKg,
      material: dto.material,
      color: dto.color,
      price: dto.price,
      stockQuantity: dto.stockQuantity ?? 0,
      category: dto.categoryId ? { id: dto.categoryId } as any : null,
      createdBy: { id: userId } as any,
    });
    return this.repo.save(box);
  }

  async update(id: number, dto: Partial<CreateBoxDto>) {
    const box = await this.findOne(id);
    const { categoryId, ...rest } = dto;
    Object.assign(box, rest);
    if (categoryId !== undefined) {
      box.category = categoryId ? { id: categoryId } as any : null;
    }
    return this.repo.save(box);
  }

  async remove(id: number) {
    const box = await this.findOne(id);
    await this.repo.remove(box);
  }
}

@Controller('boxes')
export class BoxesController {
  constructor(private svc: BoxesService) {}

  @Get()
  findAll(@Query('categoryId') categoryId?: string) {
    return this.svc.findAll(categoryId ? parseInt(categoryId) : undefined);
  }

  @Get(':id')
  findOne(@Param('id', ParseIntPipe) id: number) { return this.svc.findOne(id); }

  @Post()
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles('admin', 'manager')
  create(@Body() dto: CreateBoxDto, @Request() req) {
    return this.svc.create(dto, req.user.id);
  }

  @Put(':id')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles('admin', 'manager')
  update(@Param('id', ParseIntPipe) id: number, @Body() dto: CreateBoxDto) {
    return this.svc.update(id, dto);
  }

  @Delete(':id')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles('admin')
  remove(@Param('id', ParseIntPipe) id: number) { return this.svc.remove(id); }
}

@Module({
  imports: [TypeOrmModule.forFeature([Box])],
  providers: [BoxesService],
  controllers: [BoxesController],
  exports: [BoxesService],
})
export class BoxesModule {}
